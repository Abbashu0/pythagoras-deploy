#!/usr/bin/env python3
"""
Understand Anything Dashboard — Standalone Launcher
===================================================

This script starts a local HTTP server and opens the Understand Anything
dashboard in your default browser. No installation required — just Python 3.

Usage:
    python3 serve.py              # Default port 8080
    python3 serve.py 9000         # Custom port
    python3 serve.py 8080 --no-open   # Don't auto-open browser

Then open: http://localhost:8080
"""

import http.server
import socketserver
import webbrowser
import sys
import os
from pathlib import Path

PORT = 8080
DIRECTORY = Path(__file__).parent.absolute()

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DIRECTORY), **kwargs)

    def end_headers(self):
        # Add CORS headers for local development
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    def log_message(self, format, *args):
        # Minimal logging
        pass

def main():
    port = PORT
    open_browser = True

    # Parse args
    args = sys.argv[1:]
    if args:
        try:
            port = int(args[0])
        except ValueError:
            pass
    if '--no-open' in args:
        open_browser = False

    # Check if knowledge-graph.json exists
    graph_file = DIRECTORY / "knowledge-graph.json"
    if not graph_file.exists():
        print(f"[ERROR] knowledge-graph.json not found in {DIRECTORY}")
        print("   Make sure you're running this script from the dashboard folder.")
        sys.exit(1)

    # Print info
    print("=" * 60)
    print("  Understand Anything Dashboard - Standalone")
    print("=" * 60)
    print(f"  Serving from: {DIRECTORY}")
    print(f"  URL: http://localhost:{port}")
    print(f"  Graph size: {graph_file.stat().st_size // 1024} KB")
    print("=" * 60)
    print()
    print("  Press Ctrl+C to stop the server")
    print()

    # Open browser
    if open_browser:
        url = f"http://localhost:{port}"
        print(f"  Opening browser: {url}")
        webbrowser.open(url)

    # Start server
    try:
        with socketserver.TCPServer(("", port), Handler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\n  Server stopped. Bye!")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"\n[ERROR] Port {port} is already in use. Try a different port:")
            print(f"   python3 serve.py {port + 1}")
        else:
            raise

if __name__ == "__main__":
    main()
