# Understand Anything Dashboard — Standalone

This is the **Understand Anything** interactive dashboard for the Pythagoras Platform project, packaged as a self-contained folder you can run locally without any server setup.

## Quick Start

### Option 1: Python (recommended — already installed on most systems)

```bash
# Extract the ZIP
unzip understand-anything-dashboard.zip
cd understand-anything-dashboard

# Run the server
python3 serve.py
```

The dashboard opens automatically at http://localhost:8080

### Option 2: Any HTTP server

If you have Node.js, PHP, or any other HTTP server, just serve this folder:

```bash
# Node.js (npx http-server)
npx http-server -p 8080

# PHP
php -S localhost:8080

# Python 2
python -m SimpleHTTPServer 8080
```

Then open http://localhost:8080 in your browser.

### Option 3: VS Code Live Server

If you use VS Code with the "Live Server" extension:
1. Open this folder in VS Code
2. Right-click `index.html` → "Open with Live Server"

## What's Inside

```
understand-anything-dashboard/
├── index.html              ← Main dashboard page
├── serve.py                ← Python server launcher (recommended)
├── README.md               ← This file
├── knowledge-graph.json    ← The project's code graph (529 nodes)
├── meta.json               ← Project metadata
├── config.json             ← Dashboard config
├── file-content.json       ← Source file content (placeholder)
├── diff-overlay.json       ← Git diff overlay (empty)
├── domain-graph.json       ← Business domain graph (empty)
├── staleness.json          ← Graph freshness status
├── favicon.svg             ← Icon
└── assets/                 ← JS + CSS bundles
    ├── index-BSUMpTki.js   ← Main app bundle
    ├── react-vendor-*.js   ← React runtime
    ├── xyflow-*.js         ← Graph visualization engine
    ├── graph-layout-*.js   ← Layout algorithms
    ├── elk-*.js            ← ELK layout engine
    └── *.css               ← Styles
```

## Dashboard Features

- **Structural View** — Interactive graph of files, functions, and classes
- **Learn Mode** — Guided tour through the codebase architecture
- **Search** — Find nodes by name, summary, or tags
- **Filter Pills** — Show/hide by layer (CODE, CONFIG, DATA, etc.)
- **Path Finder** — Trace how two nodes connect
- **Right Sidebar** — Click any node for details, code, and relationships
- **Language Lessons** — Educational explanations for patterns used

## Graph Contents

This graph represents the Pythagoras Platform codebase:
- **256 file nodes** — All source files
- **65 class nodes** — All classes
- **200 function nodes** — Top 200 most-connected functions
- **568 edges** — imports, calls, contains relationships

## Troubleshooting

**"Port 8080 already in use"**
```bash
python3 serve.py 9000   # Use a different port
```

**Dashboard shows but graph is empty**
- Make sure `knowledge-graph.json` is in the same folder as `serve.py`
- Check browser console (F12) for errors

**Browser shows "Access Token Required"**
- This shouldn't happen — the index.html auto-sets the token
- If it does, type anything in the token field and press Enter

## Source

Built from: https://github.com/Egonex-AI/Understand-Anything
Graph data: Pythagoras Platform (https://github.com/Abbashu0/pythagoras-deploy)
