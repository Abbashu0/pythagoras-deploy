#!/bin/bash
# safe-commit.sh — احفظ كل التغييرات فوراً في git
#
# الاستخدام:
#   bash /home/z/my-project/scripts/safe-commit.sh "وصف قصير للتغييرات"
#
# إذا لم تُمرر رسالة، يُستخدم timestamp تلقائياً.
# السكريبت آمن: لا يحذف شيئاً، فقط يضيف ويلتزم.

set -e
cd /home/z/my-project

# رسالة الالتزام
MSG="${1:-auto-save $(date '+%Y-%m-%d %H:%M:%S')}"

# تحقق من وجود تغييرات
if git diff --quiet HEAD 2>/dev/null && [ -z "$(git ls-files --others --exclude-standard)" ]; then
  echo "✓ لا توجد تغييرات غير محفوظة — كل شيء ملتزم بالفعل"
  exit 0
fi

# أضف كل التغييرات (بما فيها الملفات الجديدة)
git add -A

# التزم
git commit -m "$MSG" --allow-empty-message 2>&1 | tail -3

# اعرض آخر 3 التزامات للتأكيد
echo ""
echo "=== آخر 3 التزامات ==="
git log --oneline -3
echo ""
echo "✓ تم الحفظ بنجاح. الآن حتى لو أُغلق الحاسوب، العمل محفوظ."
