#!/bin/bash
# autosave-daemon.sh — حفظ تلقائي صامت كل 5 دقائق
#
# يعمل في الخلفية (باستخدام setsid + nohup) ويلتزم بأي تغييرات
# غير محفوظة كل 5 دقائق. لا يلتزم إذا لم تكن هناك تغييرات.
#
# التشغيل:
#   bash /home/z/my-project/scripts/autosave-daemon.sh start
#   bash /home/z/my-project/scripts/autosave-daemon.sh stop
#   bash /home/z/my-project/scripts/autosave-daemon.sh status
#
# السجل: /home/z/my-project/scripts/autosave.log

INTERVAL=300  # 5 دقائق
PROJECT_DIR="/home/z/my-project"
LOG_FILE="$PROJECT_DIR/scripts/autosave.log"
PID_FILE="$PROJECT_DIR/scripts/autosave.pid"

case "$1" in
  start)
    # تحقق مما إذا كان يعمل بالفعل
    if [ -f "$PID_FILE" ] && kill -0 "$(cat $PID_FILE)" 2>/dev/null; then
      echo "⚠️  الـ daemon يعمل بالفعل (PID $(cat $PID_FILE))"
      exit 0
    fi

    # ابدأ الـ daemon في الخلفية
    (
      echo "[autosave] بدأ الـ daemon في $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
      while true; do
        sleep "$INTERVAL"
        cd "$PROJECT_DIR" || exit 1

        # تحقق من وجود تغييرات
        if git diff --quiet HEAD 2>/dev/null && [ -z "$(git ls-files --others --exclude-standard)" ]; then
          # لا توجد تغييرات — لا شيء
          :
        else
          # توجد تغييرات — التزم بها
          git add -A
          TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
          git commit -m "auto-save: $TIMESTAMP" --allow-empty-message 2>&1 | tail -1 >> "$LOG_FILE"
          echo "[autosave] تم الحفظ التلقائي في $TIMESTAMP" >> "$LOG_FILE"
        fi
      done
    ) &
    DAEMON_PID=$!
    echo "$DAEMON_PID" > "$PID_FILE"
    disown $DAEMON_PID 2>/dev/null || true
    echo "✓ بدأ الـ daemon (PID $DAEMON_PID) — يحفظ كل $INTERVAL ثانية"
    echo "  السجل: $LOG_FILE"
    echo "  لإيقافه: bash $0 stop"
    ;;

  stop)
    if [ -f "$PID_FILE" ]; then
      PID=$(cat "$PID_FILE")
      if kill -0 "$PID" 2>/dev/null; then
        kill "$PID" 2>/dev/null
        rm -f "$PID_FILE"
        echo "[autosave] توقف الـ daemon في $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
        echo "✓ تم إيقاف الـ daemon (PID $PID)"
      else
        rm -f "$PID_FILE"
        echo "⚠️  الـ daemon ليس قيد التشغيل (PID قديم)"
      fi
    else
      echo "⚠️  الـ daemon ليس قيد التشغيل"
    fi
    ;;

  status)
    if [ -f "$PID_FILE" ] && kill -0 "$(cat $PID_FILE)" 2>/dev/null; then
      echo "✓ الـ daemon يعمل (PID $(cat $PID_FILE))"
      echo "  آخر 5 سجلات:"
      tail -5 "$LOG_FILE" 2>/dev/null | sed 's/^/    /'
    else
      echo "✗ الـ daemon لا يعمل"
    fi
    ;;

  *)
    echo "الاستخدام: $0 {start|stop|status}"
    exit 1
    ;;
esac
